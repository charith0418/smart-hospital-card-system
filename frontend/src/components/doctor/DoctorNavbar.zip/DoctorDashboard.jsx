import React, { useState } from "react";
import { 
  FaSearch, 
  FaQrcode, 
  FaExclamationTriangle, 
  FaFileMedical, 
  FaTimes, 
  FaStethoscope, 
  FaPlus, 
  FaPrescriptionBottleAlt, 
  FaCheckCircle, 
  FaHistory, 
  FaCapsules, 
  FaTrashAlt, 
  FaThLarge, 
  FaFilePrescription, 
  FaSignOutAlt, 
  FaUserMd,
  FaHeartbeat
} from "react-icons/fa";

// --- GLOBAL MOCK DATA MATCHING YOUR DESIGNS ---
const mockPatients = {
  P10024: {
    id: "P10024",
    name: "Alexander Mercer",
    age: 27,
    gender: "Male",
    bloodGroup: "B+",
    dob: "15 May 1995",
    allergies: ["Penicillin", "Seafood", "Dust"],
    surgeries: [
      { name: "Appendectomy", doctor: "Dr. N. Silva", date: "12 Mar 2022" },
      { name: "Knee Arthroscopy", doctor: "Dr. K. Perera", date: "05 Aug 2020" }
    ],
    history: [
      { diagnosis: "Hypertension", doctor: "Dr. N. Silva", date: "12 Apr 2026", notes: "Reduce salt intake. Drink enough water. Visit again after one month." },
      { diagnosis: "Asthma", doctor: "Dr. K. Perera", date: "02 Feb 2026", notes: "Prescribed inhaler maintenance updates." },
      { diagnosis: "Diabetes Type II", doctor: "Dr. N. Silva", date: "18 Nov 2025", notes: "Routine glycemic control evaluation." },
      { diagnosis: "Seasonal Allergy", doctor: "Dr. Fernando", date: "05 Aug 2025", notes: "Antihistamine schedule assigned." }
    ],
    prescriptions: [
      {
        id: "RX-2026-001",
        doctor: "Dr. N. Silva",
        hospital: "National Hospital Colombo",
        date: "12 Apr 2026",
        diagnosis: "Hypertension",
        instructions: "Reduce salt intake. Drink enough water. Visit again after one month.",
        medicines: [
          { name: "Amlodipine 5mg", dosage: "1 Tablet", frequency: "Morning", duration: "30 Days" },
          { name: "Aspirin 75mg", dosage: "1 Tablet", frequency: "Night", duration: "30 Days" }
        ]
      }
    ]
  }
};

const hospitalFormulary = [
  "Amoxicillin 500mg",
  "Azithromycin 250mg",
  "Ibuprofen 400mg",
  "Paracetamol 500mg",
  "Omeprazole 20mg",
  "Cetirizine 10mg",
  "Metformin 850mg"
];

const standardDosages = ["Take 1 capsule every 8 hours (TID)", "Take 1 tablet daily in morning (QD)", "Take 1 tablet every 12 hours (BID)", "Take 1 tablet as needed for pain (PRN)"];
const standardDurations = ["5 Days Course", "7 Days Course", "10 Days Course", "30 Days Chronic Refill"];

// --- FULLY INTEGRATED POPUP MODALS FROM YOUR DESIGNS ---

// Design 1: Medical History Layout Popup
const MedicalHistoryModal = ({ patient, onClose }) => {
  const [searchTerm, setSearchTerm] = useState("");
  
  const filteredHistory = patient.history.filter(h => 
    h.diagnosis.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] overflow-y-auto border border-slate-200 flex flex-col">
        {/* Header */}
        <div className="bg-blue-600 text-white p-5 flex justify-between items-center rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="text-2xl"><FaHeartbeat /></div>
            <div>
              <h3 className="text-xl font-black tracking-wide">Medical History</h3>
              <p className="text-xs text-blue-100 font-medium">Complete Patient Medical Records</p>
            </div>
          </div>
          <button onClick={onClose} className="text-white hover:text-blue-200 text-2xl p-1 cursor-pointer">
            <FaTimes />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 bg-slate-50/50 flex-1">
          {/* Patient Quick Info Card */}
          <div className="bg-blue-50/40 border border-blue-100 p-4 rounded-xl grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <span className="text-xs text-slate-400 block font-bold">Patient Name</span>
              <span className="text-slate-800 font-black">{patient.name}</span>
            </div>
            <div>
              <span className="text-xs text-slate-400 block font-bold">Age</span>
              <span className="text-slate-800 font-black">{patient.age}</span>
            </div>
            <div>
              <span className="text-xs text-slate-400 block font-bold">Blood Group</span>
              <span className="text-red-600 font-black">{patient.bloodGroup}</span>
            </div>
            <div>
              <span className="text-xs text-slate-400 block font-bold">Date of Birth</span>
              <span className="text-slate-800 font-black">{patient.dob}</span>
            </div>
          </div>

          {/* Search bar */}
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-slate-400"><FaSearch /></span>
            <input 
              type="text"
              placeholder="Search diagnosis..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white rounded-xl border border-slate-300 pl-11 pr-4 py-3 text-sm font-medium outline-none focus:border-blue-500 shadow-xs"
            />
          </div>

          {/* History Records Table */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider">
                  <th className="p-4">Diagnosis</th>
                  <th className="p-4">Doctor</th>
                  <th className="p-4">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm font-bold text-slate-600">
                {filteredHistory.map((h, i) => (
                  <tr key={i} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-4 text-slate-900">{h.diagnosis}</td>
                    <td className="p-4">{h.doctor}</td>
                    <td className="p-4 font-mono text-xs">{h.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Grid Layout for Surgeries & Allergies */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Surgeries Column */}
            <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-xs space-y-3">
              <h4 className="font-black text-slate-800 text-base flex items-center gap-2 border-b border-slate-100 pb-2">
                🩺 Previous Surgeries
              </h4>
              <div className="space-y-3 max-h-40 overflow-y-auto pr-1">
                {patient.surgeries.map((s, idx) => (
                  <div key={idx} className="flex justify-between items-start text-xs border-b border-dashed border-slate-100 pb-2 last:border-0">
                    <div>
                      <span className="font-black text-slate-800 block text-sm">{s.name}</span>
                      <span className="text-slate-400 font-medium">{s.doctor}</span>
                    </div>
                    <span className="font-mono font-bold text-slate-400">{s.date}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Allergies Column */}
            <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-xs space-y-3">
              <h4 className="font-black text-red-700 text-base flex items-center gap-2 border-b border-slate-100 pb-2">
                ⚠️ Allergies
              </h4>
              <ul className="space-y-2 max-h-40 overflow-y-auto text-sm font-bold text-slate-600 pl-2 list-disc list-inside">
                {patient.allergies.map((allergy, idx) => (
                  <li key={idx} className="text-slate-700">{allergy}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Design 2: Prescriptions & Treatments Layout Popup
const PrescriptionsRecordsModal = ({ patient, onClose }) => {
  const [activeRxIndex, setActiveRxIndex] = useState(0);
  const [rxSearch, setRxSearch] = useState("");

  if (!patient.prescriptions || patient.prescriptions.length === 0) {
    return (
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
        <div className="bg-white p-6 rounded-2xl max-w-md w-full text-center">
          <p className="font-black text-slate-700">No generated prescription transcripts saved to this record folder.</p>
          <button onClick={onClose} className="mt-4 px-4 py-2 bg-slate-900 text-white rounded-xl font-bold">Dismiss</button>
        </div>
      </div>
    );
  }

  const currentRx = patient.prescriptions[activeRxIndex];
  const filteredRxList = patient.prescriptions.filter(rx => 
    rx.id.toLowerCase().includes(rxSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] overflow-y-auto border border-slate-200 flex flex-col">
        {/* Header */}
        <div className="bg-blue-600 text-white p-5 flex justify-between items-center rounded-t-2xl">
          <div className="flex items-center gap-3">
            <span className="text-2xl">💊</span>
            <div>
              <h3 className="text-xl font-black tracking-wide">Prescriptions & Treatments</h3>
              <p className="text-xs text-blue-100 font-medium">Patient Prescription Records</p>
            </div>
          </div>
          <button onClick={onClose} className="text-white hover:text-blue-200 text-2xl p-1 cursor-pointer">
            <FaTimes />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 bg-slate-50/50 flex-1">
          {/* Search Block */}
          <div className="relative">
            <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-slate-400"><FaSearch /></span>
            <input 
              type="text"
              placeholder="Search Prescription..."
              value={rxSearch}
              onChange={(e) => setRxSearch(e.target.value)}
              className="w-full bg-white rounded-xl border border-slate-300 pl-11 pr-4 py-3 text-sm font-medium outline-none focus:border-blue-500 shadow-xs"
            />
          </div>

          {/* Active Prescription Main Card */}
          {currentRx && (
            <div className="space-y-6 animate-fadeIn">
              <div className="bg-blue-50/30 border border-blue-100 p-5 rounded-xl text-sm font-medium text-slate-600 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <h4 className="text-base font-black text-slate-800 mb-2">{currentRx.id}</h4>
                  <div><span className="text-slate-400 font-bold">Doctor:</span> <span className="text-slate-800 font-bold">{currentRx.doctor}</span></div>
                  <div><span className="text-slate-400 font-bold">Hospital:</span> <span className="text-slate-800 font-bold">{currentRx.hospital}</span></div>
                </div>
                <div className="space-y-1.5 sm:text-right sm:self-end">
                  <div><span className="text-slate-400 font-bold">Date:</span> <span className="text-slate-800 font-mono font-bold">{currentRx.date}</span></div>
                  <div><span className="text-slate-400 font-bold">Diagnosis:</span> <span className="text-slate-800 font-bold">{currentRx.diagnosis}</span></div>
                  <div><span className="text-slate-400 font-bold">Patient:</span> <span className="text-slate-800 font-black">{patient.name}</span></div>
                </div>
              </div>

              {/* Medicine Table */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider">
                      <th className="p-4">Medicine</th>
                      <th className="p-4">Dosage</th>
                      <th className="p-4">Frequency</th>
                      <th className="p-4">Duration</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm font-bold text-slate-600">
                    {currentRx.medicines.map((m, idx) => (
                      <tr key={idx}>
                        <td className="p-4 text-slate-900">{m.name}</td>
                        <td className="p-4 text-slate-500">{m.dosage}</td>
                        <td className="p-4 text-slate-500">{m.frequency}</td>
                        <td className="p-4 text-slate-500">{m.duration}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Instruction Panel Block */}
              <div className="bg-emerald-50 border border-emerald-100 p-5 rounded-xl space-y-2">
                <h5 className="text-sm font-black text-emerald-800 uppercase tracking-wide">Treatments & Instructions</h5>
                <p className="text-sm font-semibold text-slate-700 leading-relaxed">{currentRx.instructions}</p>
              </div>
            </div>
          )}

          {/* Bottom Historical Selection Bar Toggle */}
          <div className="space-y-2.5">
            <h5 className="text-sm font-black text-slate-500 uppercase tracking-wider">Previous Prescriptions</h5>
            <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
              {filteredRxList.map((rx, index) => (
                <div 
                  key={rx.id}
                  className={`p-3.5 bg-white border rounded-xl flex justify-between items-center transition-all ${activeRxIndex === index ? 'border-blue-500 ring-2 ring-blue-500/10' : 'border-slate-200 hover:border-slate-300'}`}
                >
                  <div className="flex gap-4 items-center text-sm font-bold">
                    <span className="text-slate-900">{rx.id}</span>
                    <span className="text-slate-400 font-mono text-xs">{rx.date}</span>
                  </div>
                  <button 
                    onClick={() => setActiveRxIndex(index)}
                    className="text-xs bg-blue-50 text-blue-600 border border-blue-200 px-3 py-1.5 rounded-lg font-black hover:bg-blue-600 hover:text-white transition-colors cursor-pointer flex items-center gap-1"
                  >
                    👁 View
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- MAIN CONTROLLER COMPONENT ---
export default function ClinicalWorkspace({ onLogout }) {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [searchId, setSearchId] = useState("");
  const [activePatient, setActivePatient] = useState(null);
  const [searchError, setSearchError] = useState("");

  const [showTreatmentModal, setShowTreatmentModal] = useState(false);
  const [showPrescriptionModal, setShowPrescriptionModal] = useState(false);
  
  // Custom design popup window triggers
  const [showMedicalHistoryPopup, setShowMedicalHistoryPopup] = useState(false);
  const [showRxPopup, setShowRxPopup] = useState(false);

  const [diagnosedCondition, setDiagnosedCondition] = useState("");
  const [newAllergies, setNewAllergies] = useState("");
  const [treatmentNotes, setTreatmentNotes] = useState("");
  
  const [drugSearch, setDrugSearch] = useState("");
  const [selectedDrug, setSelectedDrug] = useState("");
  const [selectedDosage, setSelectedDosage] = useState(standardDosages[0]);
  const [selectedDuration, setSelectedDuration] = useState(standardDurations[0]);
  const [currentPrescriptionList, setCurrentPrescriptionList] = useState([]);

  const filteredDrugs = drugSearch && selectedDrug !== drugSearch
    ? hospitalFormulary.filter(d => d.toLowerCase().includes(drugSearch.toLowerCase()))
    : [];

  const handlePatientSearch = (e, directId = null) => {
    if (e) e.preventDefault();
    const idToLookup = (directId || searchId).trim().toUpperCase();
    
    if (mockPatients[idToLookup]) {
      setActivePatient(mockPatients[idToLookup]);
      setSearchError("");
    } else {
      setActivePatient(null);
      setSearchError("No active medical record matching that identifier string was located.");
    }
  };

  const clearActivePatient = () => {
    setActivePatient(null);
    setSearchId("");
    setDiagnosedCondition("");
    setNewAllergies("");
    setTreatmentNotes("");
    setCurrentPrescriptionList([]);
  };

  const addDrugToPrescription = () => {
    if (!selectedDrug) return;
    setCurrentPrescriptionList([
      ...currentPrescriptionList,
      { drug: selectedDrug, dosage: selectedDosage, duration: selectedDuration }
    ]);
    setDrugSearch("");
    setSelectedDrug("");
  };

  const removeDrugFromPrescription = (index) => {
    setCurrentPrescriptionList(currentPrescriptionList.filter((_, i) => i !== index));
  };

  const handleSaveConsultation = () => {
    alert(`Case records successfully signed & transmitted to database for patient: ${activePatient.name}`);
    clearActivePatient();
  };

  const renderDoctorContent = () => {
    switch (activeTab) {
      case "dashboard":
        return (
          <div className="space-y-10 animate-fadeIn w-full">
            
            {!activePatient && (
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 items-stretch w-full pt-6">
                <div className="xl:col-span-2 bg-white p-8 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-center">
                  <h3 className="text-sm font-black uppercase tracking-widest text-slate-400 mb-4">Patient Database Lookup</h3>
                  <form onSubmit={(e) => handlePatientSearch(e)} className="flex gap-4">
                    <div className="flex bg-slate-50 rounded-xl border-2 border-slate-200 overflow-hidden focus-within:border-[#078a72] transition-all flex-1">
                      <input 
                        type="text" 
                        placeholder="Enter Patient ID Code (Use 'P10024' for dynamic preview)..." 
                        value={searchId}
                        onChange={(e) => setSearchId(e.target.value)}
                        className="w-full bg-transparent px-6 py-4 outline-none text-xl font-bold placeholder-slate-400"
                      />
                    </div>
                    <button type="submit" className="bg-[#078a72] hover:bg-[#056b58] text-white px-10 rounded-xl text-xl font-black shadow-md flex items-center gap-3 transition-colors cursor-pointer">
                      <FaSearch /> View
                    </button>
                  </form>
                  {searchError && <p className="text-red-600 font-bold text-base mt-3 ml-2">⚠️ {searchError}</p>}
                </div>
                
                <div className="w-full">
                  <div 
                    onClick={() => { 
                      setSearchId("P10024"); 
                      handlePatientSearch(null, "P10024");
                    }} 
                    className="bg-white border-3 border-dashed border-[#078a72] bg-emerald-50/10 p-8 rounded-2xl shadow-sm text-center h-full flex flex-col justify-center items-center group cursor-pointer hover:bg-emerald-50/40 transition-all duration-300"
                  >
                    <h3 className="text-slate-900 font-black mb-3 text-xl tracking-wide">Scan Patient Card</h3>
                    <div className="w-20 h-20 bg-[#078a72]/10 rounded-2xl flex items-center justify-center text-[#078a72] text-4xl animate-pulse group-hover:scale-110 transition-transform">
                      <FaQrcode />
                    </div>
                    <p className="text-sm font-black text-slate-400 mt-4 uppercase tracking-widest group-hover:text-[#078a72]">
                      Launch Camera Scanner
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activePatient && (
              <div className="space-y-8 animate-slideUp w-full">
                
                <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-md flex flex-col sm:flex-row justify-between items-center gap-4">
                  <div className="flex items-center gap-5">
                    <div className="w-16 h-16 rounded-xl bg-[#078a72] font-black text-2xl flex items-center justify-center border border-white/10 uppercase">
                      {activePatient.name.charAt(0)}
                    </div>
                    <div>
                      <h2 className="text-3xl font-black tracking-tight">{activePatient.name}</h2>
                      <div className="text-base text-slate-300 font-medium mt-1 flex flex-wrap items-center gap-2">
                        <span>ID:</span> <span className="font-mono font-bold text-[#078a72] bg-white/10 px-2 py-0.5 rounded text-sm">{activePatient.id}</span> <span>• Age: {activePatient.age} • Gender: {activePatient.gender} • Blood Group:</span> <span className="text-amber-400 font-black">{activePatient.bloodGroup}</span>
                        {activePatient.allergies && activePatient.allergies.length > 0 && (
                          <span className="ml-2 bg-red-600/20 text-red-400 border border-red-500/30 px-2.5 py-0.5 rounded-md text-xs font-black flex items-center gap-1 uppercase tracking-wider">
                            <FaExclamationTriangle /> Severe Allergies Configured
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => setShowMedicalHistoryPopup(true)} 
                      className="p-3 bg-blue-600 text-white hover:bg-blue-700 rounded-xl transition text-sm cursor-pointer flex items-center gap-2 font-bold shadow-sm"
                    >
                      <FaFileMedical /> Open Medical History Popup
                    </button>
                    <button 
                      onClick={() => setShowRxPopup(true)} 
                      className="p-3 bg-indigo-600 text-white hover:bg-indigo-700 rounded-xl transition text-sm cursor-pointer flex items-center gap-2 font-bold shadow-sm"
                    >
                      <FaPrescriptionBottleAlt /> Open Prescription Panel Popup
                    </button>
                    <button 
                      onClick={clearActivePatient} 
                      className="p-3 bg-white/10 text-white hover:bg-red-600 rounded-xl transition text-sm cursor-pointer flex items-center gap-2 font-bold"
                    >
                      <FaTimes /> Close File
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start w-full">
                  <div className="lg:col-span-2 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      
                      {/* TREATMENT ENTRY HUB */}
                      <div className="bg-white p-6 border border-slate-200 rounded-2xl shadow-sm flex flex-col justify-between space-y-4">
                        <div className="flex items-start gap-4">
                          <div className="p-4 bg-teal-50 text-[#078a72] rounded-xl text-2xl">
                            <FaStethoscope />
                          </div>
                          <div>
                            <h4 className="text-xl font-black text-slate-900">Clinical Treatment</h4>
                            <p className="text-sm text-slate-400 font-medium mt-1">Record findings, primary conditions, diagnoses, and general treatment notes.</p>
                          </div>
                        </div>
                        {diagnosedCondition && (
                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs font-bold text-slate-700">
                            <span className="text-slate-400 uppercase tracking-wider block text-[10px]">Staged Condition:</span>
                            {diagnosedCondition}
                          </div>
                        )}
                        <button 
                          onClick={() => setShowTreatmentModal(true)}
                          className="w-full py-3 bg-[#078a72] hover:bg-[#056b58] text-white font-black rounded-xl shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
                        >
                          <FaPlus /> Open Treatment Log
                        </button>
                      </div>

                      {/* PRESCRIPTION HUB */}
                      <div className="bg-white p-6 border border-slate-200 rounded-2xl shadow-sm flex flex-col justify-between space-y-4">
                        <div className="flex items-start gap-4">
                          <div className="p-4 bg-emerald-50 text-emerald-600 rounded-xl text-2xl">
                            <FaPrescriptionBottleAlt />
                          </div>
                          <div>
                            <h4 className="text-xl font-black text-slate-900">Medication Script</h4>
                            <p className="text-sm text-slate-400 font-medium mt-1">Browse hospital drug formularies to construct step-by-step prescription sheets.</p>
                          </div>
                        </div>
                        {currentPrescriptionList.length > 0 && (
                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs font-bold text-slate-700">
                            <span className="text-slate-400 uppercase tracking-wider block text-[10px]">Staged Items:</span>
                            {currentPrescriptionList.length} Drugs Staged
                          </div>
                        )}
                        <button 
                          onClick={() => setShowPrescriptionModal(true)}
                          className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
                        >
                          <FaPlus /> Open Prescription Hub
                        </button>
                      </div>

                    </div>

                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                      <button 
                        onClick={handleSaveConsultation}
                        disabled={!diagnosedCondition && currentPrescriptionList.length === 0 && !newAllergies}
                        className="w-full py-4 bg-slate-900 text-white rounded-xl text-xl font-black shadow-md flex items-center justify-center gap-3 hover:bg-black transition-colors cursor-pointer disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed"
                      >
                        <FaCheckCircle /> Authorize & Sign Complete Case File
                      </button>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="bg-red-50/50 border border-red-200 p-6 rounded-2xl space-y-4 shadow-sm">
                      <div className="flex items-center gap-2 border-b border-red-100 pb-3 text-red-700">
                        <FaExclamationTriangle className="text-xl" />
                        <h4 className="text-lg font-black uppercase tracking-wider">Patient Allergies Vault</h4>
                      </div>
                      {activePatient.allergies && activePatient.allergies.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {activePatient.allergies.map((allergy, idx) => (
                            <span key={idx} className="bg-red-600 text-white font-black px-3 py-1.5 rounded-xl text-xs tracking-wide shadow-sm uppercase">
                              ⚠️ {allergy}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm font-bold text-slate-500">No known allergies documented.</p>
                      )}
                    </div>

                    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                      <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                        <FaHistory className="text-slate-400 text-xl" />
                        <h4 className="text-lg font-black text-slate-900">Historical Health Timeline</h4>
                      </div>
                      <div className="space-y-4 max-h-[400px] overflow-y-auto pr-1">
                        <p className="text-xs font-black uppercase tracking-wider text-slate-400">Past Diagnoses</p>
                        {activePatient.history.map((h, i) => (
                          <div key={i} className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-1 text-sm">
                            <div className="flex justify-between font-mono text-xs font-bold text-slate-400">
                              <span>📅 {h.date}</span>
                              <span className="text-[#078a72] font-bold">{h.doctor}</span>
                            </div>
                            <h5 className="font-black text-slate-900">{h.diagnosis}</h5>
                            <p className="text-xs text-slate-600 leading-relaxed mt-1">{h.notes}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* DEFAULT SYSTEM MODALS */}
            {showTreatmentModal && (
              <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
                <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 flex flex-col">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50 rounded-t-2xl">
                    <div className="flex items-center gap-3">
                      <FaStethoscope className="text-[#078a72] text-2xl" />
                      <h3 className="text-2xl font-black text-slate-900">Clinical Treatment & Findings</h3>
                    </div>
                    <button onClick={() => setShowTreatmentModal(false)} className="text-slate-400 hover:text-slate-600 text-xl p-2 cursor-pointer">
                      <FaTimes />
                    </button>
                  </div>
                  
                  <div className="p-6 space-y-6 flex-1">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-black text-slate-500 uppercase tracking-wider mb-2">Primary Diagnosis</label>
                        <input 
                          type="text" 
                          placeholder="e.g., Acute Pharyngitis..."
                          value={diagnosedCondition}
                          onChange={(e) => setDiagnosedCondition(e.target.value)}
                          className="w-full bg-slate-50 rounded-xl border-2 border-slate-200 px-5 py-3.5 text-lg font-bold outline-none focus:border-[#078a72] transition-colors"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-black text-red-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                          <FaExclamationTriangle /> Record Newly Noted Allergies
                        </label>
                        <input 
                          type="text" 
                          placeholder="Type allergy triggers..."
                          value={newAllergies}
                          onChange={(e) => setNewAllergies(e.target.value)}
                          className="w-full bg-red-50/10 rounded-xl border-2 border-red-200 focus:border-red-500 px-5 py-3.5 text-lg font-bold outline-none transition-colors text-red-700 placeholder-red-300"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-black text-slate-500 uppercase tracking-wider mb-2">Clinical Notes & Management Advice</label>
                      <textarea 
                        rows="4"
                        placeholder="Type internal medical checkup notes or home rest directives..."
                        value={treatmentNotes}
                        onChange={(e) => setTreatmentNotes(e.target.value)}
                        className="w-full bg-slate-50 rounded-xl border-2 border-slate-200 px-5 py-4 text-base font-medium outline-none focus:border-[#078a72] transition-colors resize-none"
                      />
                    </div>
                  </div>

                  <div className="p-6 border-t border-slate-100 bg-slate-50 rounded-b-2xl flex justify-end">
                    <button 
                      onClick={() => setShowTreatmentModal(false)}
                      className="px-6 py-3 bg-slate-900 text-white font-black rounded-xl hover:bg-black transition-colors shadow-xs cursor-pointer flex items-center gap-2"
                    >
                      <FaCheckCircle /> Keep & Stash Changes
                    </button>
                  </div>
                </div>
              </div>
            )}

            {showPrescriptionModal && (
              <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
                <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 flex flex-col">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50 rounded-t-2xl">
                    <div className="flex items-center gap-3">
                      <FaPrescriptionBottleAlt className="text-emerald-600 text-2xl" />
                      <h3 className="text-2xl font-black text-slate-900">Prescription Formulation Hub</h3>
                    </div>
                    <button onClick={() => setShowPrescriptionModal(false)} className="text-slate-400 hover:text-slate-600 text-xl p-2 cursor-pointer">
                      <FaTimes />
                    </button>
                  </div>

                  <div className="p-6 space-y-6 flex-1 relative">
                    <div className="relative">
                      <label className="block text-sm font-black text-slate-500 uppercase tracking-wider mb-2">Search Medication Formulary</label>
                      <div className="flex bg-slate-50 rounded-xl border-2 border-slate-200 overflow-hidden items-center px-4 focus-within:border-[#078a72]">
                        <FaCapsules className="text-slate-400 text-xl" />
                        <input 
                          type="text" 
                          placeholder="Type brand or generic name..."
                          value={drugSearch}
                          onChange={(e) => setDrugSearch(e.target.value)}
                          className="w-full bg-transparent px-4 py-3.5 text-lg font-bold outline-none"
                        />
                      </div>
                      
                      {filteredDrugs.length > 0 && (
                        <div className="absolute left-0 right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-xl max-h-48 overflow-y-auto z-50 divide-y divide-slate-100">
                          {filteredDrugs.map((drug, idx) => (
                            <div 
                              key={idx}
                              onClick={() => { setSelectedDrug(drug); setDrugSearch(drug); }}
                              className="px-6 py-3.5 text-base font-bold text-slate-800 hover:bg-emerald-50 hover:text-[#078a72] cursor-pointer transition-colors"
                            >
                              品 {drug}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {selectedDrug && (
                      <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-4 animate-fadeIn">
                        <div className="text-sm font-black text-slate-400 uppercase tracking-widest">Selected: <span className="text-[#078a72] text-base font-black normal-case">{selectedDrug}</span></div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-black text-slate-500 uppercase tracking-wider mb-1.5">Directions / Frequency</label>
                            <select value={selectedDosage} onChange={(e) => setSelectedDosage(e.target.value)} className="w-full bg-white rounded-lg border border-slate-300 p-2.5 font-bold text-sm">
                              {standardDosages.map((d, i) => <option key={i} value={d}>{d}</option>)}
                            </select>
                          </div>
                          <div>
                            <label className="block text-xs font-black text-slate-500 uppercase tracking-wider mb-1.5">Period Duration</label>
                            <select value={selectedDuration} onChange={(e) => setSelectedDuration(e.target.value)} className="w-full bg-white rounded-lg border border-slate-300 p-2.5 font-bold text-sm">
                              {standardDurations.map((d, i) => <option key={i} value={d}>{d}</option>)}
                            </select>
                          </div>
                        </div>
                        <button type="button" onClick={addDrugToPrescription} className="w-full bg-[#078a72] hover:bg-[#056b58] text-white py-3 rounded-lg font-black text-base flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-colors">
                          <FaPlus /> Insert Medication Into List
                        </button>
                      </div>
                    )}

                    <div className="space-y-3">
                      <h5 className="text-sm font-black text-slate-400 uppercase tracking-wider">Current Session Script Output</h5>
                      {currentPrescriptionList.length === 0 ? (
                        <div className="text-center p-6 bg-slate-50 rounded-xl border border-dashed border-slate-200 text-sm text-slate-400 font-bold">
                          No items added to prescription script yet.
                        </div>
                      ) : (
                        <div className="border border-slate-200 rounded-xl overflow-hidden divide-y divide-slate-100 shadow-sm max-h-48 overflow-y-auto">
                          {currentPrescriptionList.map((med, index) => (
                            <div key={index} className="p-4 bg-white flex justify-between items-center gap-4 animate-fadeIn">
                              <div className="flex items-center gap-3">
                                <div className="w-2.5 h-2.5 rounded-full bg-[#078a72]"></div>
                                <div>
                                  <h6 className="font-black text-slate-900 text-base">{med.drug}</h6>
                                  <p className="text-xs text-slate-500 font-bold mt-0.5">{med.dosage} • <span className="text-[#078a72] font-mono">{med.duration}</span></p>
                                </div>
                              </div>
                              <button onClick={() => removeDrugFromPrescription(index)} className="text-slate-300 hover:text-red-600 p-2 text-base transition-colors cursor-pointer">
                                <FaTrashAlt />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="p-6 border-t border-slate-100 bg-slate-50 rounded-b-2xl flex justify-end">
                    <button 
                      onClick={() => setShowPrescriptionModal(false)}
                      className="px-6 py-3 bg-slate-900 text-white font-black rounded-xl hover:bg-black transition-colors shadow-sm cursor-pointer flex items-center gap-2"
                    >
                      <FaCheckCircle /> Save Script List
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* LIVE HOOKED TARGET POPUPS */}
            {showMedicalHistoryPopup && (
              <MedicalHistoryModal 
                patient={activePatient} 
                onClose={() => setShowMedicalHistoryPopup(false)} 
              />
            )}

            {showRxPopup && (
              <PrescriptionsRecordsModal 
                patient={activePatient} 
                onClose={() => setShowRxPopup(false)} 
              />
            )}

          </div>
        );
        
      case "patients":
      case "medical_history":
        return activePatient ? (
          <MedicalHistoryModal patient={activePatient} onClose={() => setActiveTab("dashboard")} />
        ) : (
          <div className="p-8 bg-white border border-slate-200 rounded-2xl shadow-sm">
            <h3 className="text-2xl font-black text-slate-800 mb-2">Patient Records Master Database</h3>
            <p className="text-slate-500 font-medium">Please lookup and select an active patient profile on the dashboard first.</p>
          </div>
        );
        
      case "prescriptions":
        return activePatient ? (
          <PrescriptionsRecordsModal patient={activePatient} onClose={() => setActiveTab("dashboard")} />
        ) : (
          <div className="p-8 bg-white border border-slate-200 rounded-2xl shadow-sm">
            <h3 className="text-2xl font-black text-slate-800 mb-2">Prescription Hub Archive</h3>
            <p className="text-slate-500 font-medium">Please lookup and select an active patient profile on the dashboard first.</p>
          </div>
        );
        
      default:
        return <div className="p-10 bg-white border border-slate-200 rounded-2xl shadow-md font-black text-2xl text-slate-800">Module View: {activeTab} Screen</div>;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-600 font-sans antialiased w-full">
      
      <aside className="w-64 bg-[#056b58] text-white flex flex-col justify-between p-4 shrink-0 shadow-lg">
        <div className="space-y-8">
          <div className="flex items-center gap-3 px-2 py-4 border-b border-white/10">
            <div className="bg-white text-[#056b58] p-2.5 rounded-xl text-xl font-black shadow-sm">+</div>
            <span className="text-xl font-black tracking-tight uppercase">Medicare Hosp</span>
          </div>

          <nav className="space-y-1">
            <button 
              onClick={() => setActiveTab("dashboard")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all cursor-pointer ${activeTab === "dashboard" ? "bg-white/10 text-white shadow-xs" : "text-emerald-100/70 hover:bg-white/5 hover:text-white"}`}
            >
              <FaThLarge className="text-lg" /> Dashboard
            </button>
            <button 
              onClick={() => setActiveTab("medical_history")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all cursor-pointer ${activeTab === "medical_history" || activeTab === "patients" ? "bg-white/10 text-white shadow-xs" : "text-emerald-100/70 hover:bg-white/5 hover:text-white"}`}
            >
              <FaFileMedical className="text-lg" /> Medical History
            </button>
            <button 
              onClick={() => setActiveTab("prescriptions")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all cursor-pointer ${activeTab === "prescriptions" ? "bg-white/10 text-white shadow-xs" : "text-emerald-100/70 hover:bg-white/5 hover:text-white"}`}
            >
              <FaFilePrescription className="text-lg" /> Prescriptions
            </button>
          </nav>
        </div>

        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-bold text-red-200 hover:bg-red-900/30 hover:text-white transition-colors border border-transparent hover:border-red-500/20 cursor-pointer text-left"
        >
          <FaSignOutAlt className="text-lg" /> Logout
        </button>
      </aside>

      <main className="flex-1 flex flex-col overflow-x-hidden min-w-0">
        
        <header className="h-20 bg-white border-b border-slate-200 px-8 flex items-center justify-between shrink-0 shadow-xs">
          <h1 className="text-2xl font-black tracking-tight text-slate-900 uppercase">Clinical Workspace</h1>
          <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 px-4 py-2 rounded-xl">
            <div className="text-right">
              <div className="text-sm font-black text-slate-900">Dr. Asela Perera</div>
              <div className="text-[10px] font-black uppercase tracking-wider text-[#078a72]">OPD Consultant • DOC-9941</div>
            </div>
            <div className="w-9 h-9 bg-[#078a72]/10 rounded-lg flex items-center justify-center text-[#078a72] text-lg font-bold">
              <FaUserMd />
            </div>
          </div>
        </header>

        <section className="p-8 flex-1 overflow-y-auto w-full max-w-[1600px] mx-auto">
          {renderDoctorContent()}
        </section>

      </main>
    </div>
  );
}