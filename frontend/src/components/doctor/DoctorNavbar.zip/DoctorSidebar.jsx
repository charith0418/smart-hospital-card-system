import React from "react";
import {
  FaPlusSquare,
  FaThLarge,
  FaSignOutAlt
} from "react-icons/fa";

const menuItems = [
  {
    name: "Dashboard",
    id: "dashboard",
    icon: <FaThLarge />
  }
];

export default function DoctorSidebar({
  sidebarOpen,
  setSidebarOpen,
  activeTab,
  setActiveTab,
  onLogout
}) {
  return (
    <aside
      className={`fixed top-0 left-0 z-50 w-64 h-screen bg-[#008060] text-white flex flex-col shadow-2xl transform transition-transform duration-300 ${
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      } xl:translate-x-0`}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-6 py-5 border-b border-white/10">
        <div className="bg-white/20 p-2 rounded-xl">
          <FaPlusSquare className="text-3xl" />
        </div>

        <div>
          <h1 className="text-lg font-bold">
            Medicare Hospital
          </h1>
        </div>
      </div>

      {/* Menu */}
      <nav className="flex-1 mt-4 px-3 space-y-2">

        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              setActiveTab(item.id);
              setSidebarOpen(false);
            }}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition ${
              activeTab === item.id
                ? "bg-white text-[#008060] font-semibold"
                : "hover:bg-white/10"
            }`}
          >
            {item.icon}
            {item.name}
          </button>
        ))}

        {/* Logout */}
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-4 px-4 py-3 rounded-xl mt-10 hover:bg-red-500/20 text-red-200"
        >
          <FaSignOutAlt />
          Logout
        </button>

      </nav>
    </aside>
  );
}